<?php
/**
* @package tests
*/
/** include */
include(('test' . 'me') . '.php');
?>
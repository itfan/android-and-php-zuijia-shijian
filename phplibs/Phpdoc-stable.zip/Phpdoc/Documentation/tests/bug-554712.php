<?php
/**
* @package tests
*/
/**
* returns a reference
*/
function &returnsme()
{
}

/**
* passes a variable by reference
*/
function passbyref(&$varname)
{
}
?>
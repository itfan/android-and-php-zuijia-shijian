<?php
/**
* @package tests
*/
/**
* @package tests
*/
class functionincomment
{


  /* function */

  function process($trxtype, $tender = 'C')
  {
  }
}

?>

<?php
/** @package tests */
/**
* test function
*
* @see	link1
* @see	link2
*/
function test_445298 ()
{
}
?>
